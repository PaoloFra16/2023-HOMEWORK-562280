package it.uniroma3.diadia.ambienti;

public enum Direzione {
	nord, est, sud, ovest
}
