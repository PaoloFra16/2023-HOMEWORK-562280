package it.uniroma3.diadia;

public class FormatoFileNonValidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FormatoFileNonValidoException(String msg){
		super(msg);
	}
}
